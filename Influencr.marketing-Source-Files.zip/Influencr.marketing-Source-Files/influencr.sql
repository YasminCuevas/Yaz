-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 08, 2020 at 09:59 PM
-- Server version: 5.6.49-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `influencr`
--

-- --------------------------------------------------------

--
-- Table structure for table `ad_details`
--

CREATE TABLE `ad_details` (
  `id` int(11) NOT NULL,
  `influencer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ad_title` varchar(191) NOT NULL,
  `ad_description` text NOT NULL,
  `date_time` varchar(191) NOT NULL,
  `ad_image` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_details`
--

INSERT INTO `ad_details` (`id`, `influencer_id`, `user_id`, `ad_title`, `ad_description`, `date_time`, `ad_image`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 'Hand wash', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.', '2020-08-01T15:40', '65044.dash-customers.png', 0, '2020-08-01 17:11:06', '2020-08-04 14:04:49'),
(2, 1, 2, 'cotten', 'n enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue.', '2020-08-05T12:21', '78738.b3.jpg', 1, '2020-08-04 13:53:21', '2020-08-12 11:55:31'),
(4, 1, 4, 'Suave Touch', 'Suave Hand Sanitizer kills 99.9% of germs. This alcohol-based hand sanitizer helps eliminate over 99.9% of many common harmful germs and bacteria.', '2020-08-05T13:53', '94550.download.jpg', 0, '2020-08-05 08:18:45', NULL),
(5, 2, 5, 'Test', 'Test', '2020-08-11T01:52', '83225.FullSizeR(26).jpg', 0, '2020-08-11 06:52:44', NULL),
(6, 10, 9, 'bhjbhn', 'guygyug', '2020-08-25T23:38', '51355.urlblockj.png', 0, '2020-08-20 04:38:38', NULL),
(8, 1, 19, 'Dipers', 'test', '2020-09-15T16:56', '40031.fr-06.jpg', 1, '2020-09-15 11:25:58', '2020-10-27 18:23:47'),
(9, 26, 1, 'swsw', 'sds', '2020-10-07T21:46', NULL, 1, '2020-09-22 02:46:32', '2020-10-02 13:42:04'),
(10, 27, 10, 'wellfair', 'test', '2020-09-22T18:50', NULL, 0, '2020-09-22 13:19:41', NULL),
(11, 1, 24, 'Sanitizer', 'test', '2020-10-02T19:12', NULL, 0, '2020-10-02 13:40:54', NULL),
(12, 1, 32, 'Sanitizer', 'test', '2020-10-14T15:06', NULL, 0, '2020-10-14 09:34:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ad_files`
--

CREATE TABLE `ad_files` (
  `id` int(11) NOT NULL,
  `ad_detail_id` int(11) NOT NULL,
  `files` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_files`
--

INSERT INTO `ad_files` (`id`, `ad_detail_id`, `files`, `created_at`, `updated_at`) VALUES
(1, 9, '49576.personal_photo-211-e1558244495625.jpg', '2020-09-22 02:46:32', NULL),
(2, 10, '65662.jgds-indietoga-women-s-blue-moss-crepe-cold-shoulder-top_500x500_0-min-final470.jpg', '2020-09-22 13:19:41', NULL),
(3, 11, '15592.jgds-indietoga-women-s-blue-moss-crepe-cold-shoulder-top_500x500_0-min-final470.jpg', '2020-10-02 13:40:55', NULL),
(4, 12, '64131.fancy-tops-500x500.jpg', '2020-10-14 09:34:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ad_reviews`
--

CREATE TABLE `ad_reviews` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ad_detail_id` int(11) DEFAULT NULL,
  `ratings` int(11) DEFAULT NULL,
  `review` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_reviews`
--

INSERT INTO `ad_reviews` (`id`, `user_id`, `ad_detail_id`, `ratings`, `review`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 0, NULL, '2020-10-03 13:11:11', NULL),
(2, 1, 4, 0, NULL, '2020-10-03 13:11:41', NULL),
(3, 1, 1, 3, 'test review', '2020-10-03 13:18:30', NULL),
(4, 2, 5, 3, 'test', '2020-10-14 06:50:20', NULL),
(5, 1, 4, 2, NULL, '2020-10-14 13:19:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `influencers`
--

CREATE TABLE `influencers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `category` varchar(191) NOT NULL,
  `followers` varchar(191) NOT NULL,
  `engagement` varchar(191) NOT NULL,
  `price` float NOT NULL,
  `social_site` varchar(255) NOT NULL,
  `icon` varchar(10) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `influencers`
--

INSERT INTO `influencers` (`id`, `user_id`, `name`, `category`, `followers`, `engagement`, `price`, `social_site`, `icon`, `image`, `created_at`, `updated_at`) VALUES
(1, 1, 'Maria Gonzales', 'Entertainment', '6', '12', 200, 'fa fa-facebook-square', '#3b5998', 'avatar2.png', '2020-07-29 10:06:46', '2020-07-29 12:47:35'),
(2, 1, 'Luna Stark', 'Bussness', '200', '48', 37, 'fa fa-instagram', '#E1306C', 'avatar.png', '2020-07-29 10:06:46', '2020-07-29 12:47:50'),
(3, 1, 'Jonathan Burke', 'Agriculture', '58', '4', 709.54, 'fa fa-facebook-square', '#3b5998', 'avatar3.png', '2020-07-29 11:48:42', '2020-07-29 12:48:05'),
(4, 1, 'Elizabeth Pirce', 'Aircraft and boat', '489', '56', 86.97, 'fa fa-instagram', '#E1306C', 'avatar04.png', '2020-07-29 11:48:42', '2020-07-29 12:47:58'),
(5, 2, 'Nora Havisham', 'Vehicle service', '566', '56', 456.87, 'fa fa-facebook-square', '#3b5998', 'avatar5.png', '2020-07-29 12:53:30', NULL),
(6, 2, 'Tasman', 'Beauty, cosmetic', '654', '56', 700, 'fa fa-instagram', '#E1306C', 'avatar04.png', '2020-07-29 12:53:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('snehalt.iwp@gmail.com', '$2y$10$1MLsMOMHzDrB7IPXNFRKw.HwoIhuKRN8WLMyl/sk2iHRs74h.XmZW', '2020-08-29 17:25:21'),
('randall@gmal.com', '$2y$10$SD/pi.naxMcDLy/qfJxL3udfYnK7PTEelIy3TX.ofKULKbW9VqpT2', '2020-08-29 19:29:25'),
('julis.iwp@gmail.com', '$2y$10$g1W5BPA4Qz7Bh3sbZS49rOq/s3s4VCbwiNYKPCb.lQoRc9Wjqv1oW', '2020-08-29 19:48:53'),
('snehaldtalwekar@gmail.com', '$2y$10$xgiafq3KqxPpcwemnc2sweChI/6tLpD/KFgJUxANMjCNUa64Q5dJi', '2020-08-29 19:54:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `facebook_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `followers` int(11) DEFAULT NULL,
  `engagement` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` float DEFAULT NULL,
  `gender` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_site` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_original` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_verified` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `google_id`, `email_verified_at`, `facebook_id`, `instagram_id`, `name`, `email`, `username`, `password`, `category`, `followers`, `engagement`, `price`, `gender`, `social_site`, `icon`, `image`, `avatar`, `avatar_original`, `link`, `verification_code`, `is_verified`, `remember_token`, `created_at`, `updated_at`) VALUES
(24, NULL, NULL, '10150001512196411', NULL, 'Ariel Ortega', 'geogatedproject241@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://graph.facebook.com/v3.0/10150001512196411/picture?type=normal', 'https://graph.facebook.com/v3.0/10150001512196411/picture?width=1920', NULL, NULL, NULL, '3DTgD6WPmJUS44ycebRaSZUASKLYi1tPhsYl9TNgotVEDmU5lNy57Tt9n9I7', '2020-09-17 13:18:17', '2020-09-17 13:18:17'),
(32, NULL, NULL, '2630394423941008', NULL, 'Juli Satpute', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://graph.facebook.com/v3.0/2630394423941008/picture?type=normal', 'https://graph.facebook.com/v3.0/2630394423941008/picture?width=1920', NULL, NULL, NULL, 'uYsUJNo6C9JrltBLiDXY3JjKJDefHura6W5NauPEf5vBI2j1iremZcXmwnks', '2020-09-28 16:54:59', '2020-09-28 16:54:59'),
(36, NULL, NULL, NULL, '17841443132320634', 'sneha.iwp', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'rWZ9XHko1ESOZ4be49Qh8GJ4ojSDSDlrsjPZZ2mvw5DWr8v3gBHr2Ivy6Lw5', '2020-10-01 19:55:25', '2020-10-01 19:55:25'),
(40, NULL, NULL, '127273862462412', NULL, 'Sneha Iwp', 'snehalt.iwp@gmail.com', NULL, NULL, 'News & media website', 1, '1', NULL, NULL, NULL, NULL, NULL, 'https://graph.facebook.com/v3.0/127273862462412/picture?type=normal', 'https://graph.facebook.com/v3.0/127273862462412/picture?width=1920', 'https://www.facebook.com/102846911585687', NULL, NULL, 'elPoPoCBt1GsCArZrk4vmpJHNufTVX5fF8uVK8MZ9nTELGC78k1fKogDF7Kn', '2020-10-07 16:37:37', '2020-10-07 16:37:37'),
(43, NULL, NULL, '3652461481484979', NULL, 'Yaz Cuevz', 'yasmin.c3@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://graph.facebook.com/v3.0/3652461481484979/picture?type=normal', 'https://graph.facebook.com/v3.0/3652461481484979/picture?width=1920', NULL, NULL, NULL, NULL, '2020-10-13 15:00:24', '2020-10-13 15:00:24'),
(44, NULL, NULL, '958187664694261', NULL, 'India Webmedia Pro', 'indiawebmediapro@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://graph.facebook.com/v3.0/958187664694261/picture?type=normal', 'https://graph.facebook.com/v3.0/958187664694261/picture?width=1920', NULL, NULL, NULL, 'SizJ9wlhwQ9yr5j0wGo2hwxbaYlp4WHeMFe07sKUaG7MKtZ8wwkPmd0txKXc', '2020-10-15 12:04:08', '2020-10-15 12:04:08'),
(45, NULL, NULL, '10149999996704517', NULL, 'Chelsey Parker', 'smooehzifo_1564791459@tfbnw.net', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://graph.facebook.com/v3.0/10149999996704517/picture?type=normal', 'https://graph.facebook.com/v3.0/10149999996704517/picture?width=1920', NULL, NULL, NULL, NULL, '2020-10-28 05:10:38', '2020-10-28 05:10:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ad_details`
--
ALTER TABLE `ad_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_files`
--
ALTER TABLE `ad_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_reviews`
--
ALTER TABLE `ad_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `influencers`
--
ALTER TABLE `influencers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ad_details`
--
ALTER TABLE `ad_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `ad_files`
--
ALTER TABLE `ad_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ad_reviews`
--
ALTER TABLE `ad_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `influencers`
--
ALTER TABLE `influencers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
